-- Schema for Nexus-Leads (Supabase / PostgreSQL)
-- This schema supports Starter, Pro, and Elite plans with trial management.

-- 1. Custom Types for Plans and Status
CREATE TYPE public.plan_type AS ENUM ('starter', 'pro', 'elite');
CREATE TYPE public.subscription_status AS ENUM ('trialing', 'active', 'canceled', 'past_due', 'unpaid');

-- 2. Profiles Table
-- Linked to Supabase Auth (auth.users)
CREATE TABLE public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  
  -- Subscription Details
  plan public.plan_type DEFAULT 'starter',
  status public.subscription_status DEFAULT 'trialing',
  
  -- Trial & Billing Dates
  trial_starts_at TIMESTAMPTZ DEFAULT NOW(),
  trial_ends_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '14 days'),
  current_period_end TIMESTAMPTZ,
  
  -- Metadata
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Search Usage Tracking
-- To enforce limits like "100 searches / month" for the Starter plan
CREATE TABLE public.search_usage (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  search_query TEXT,
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  
  -- To make it easy to query "this month's usage"
  month_year TEXT NOT NULL -- Format: 'YYYY-MM'
);

-- 4. Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.search_usage ENABLE ROW LEVEL SECURITY;

-- Policies for Profiles
CREATE POLICY "Users can view their own profile." 
  ON public.profiles FOR SELECT 
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile." 
  ON public.profiles FOR UPDATE 
  USING (auth.uid() = id);

-- Policies for Search Usage
CREATE POLICY "Users can view their own search history."
  ON public.search_usage FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own search records."
  ON public.search_usage FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- 5. Helper Function: Check if user is on active Pro/Elite plan or within trial
CREATE OR REPLACE FUNCTION public.has_active_access(user_uuid UUID)
RETURNS BOOLEAN AS $$
DECLARE
  is_valid BOOLEAN;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = user_uuid
    AND (
      plan IN ('pro', 'elite') -- Pro/Elite always have access if status is active
      OR (plan = 'starter' AND status = 'active') -- Paid Starter
      OR (trial_ends_at > NOW()) -- Currently in trial
    )
  ) INTO is_valid;
  RETURN is_valid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 6. Trigger: Automatically create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, avatar_url)
  VALUES (
    new.id, 
    new.email, 
    new.raw_user_meta_data->>'full_name', 
    new.raw_user_meta_data->>'avatar_url'
  );
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();
