/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSearch } from '../context/SearchContext';
import { useAuth } from '../context/AuthContext';
import SearchBar from '../components/SearchBar';
import LogosStrip from '../components/LogosStrip';
import TestimonialsSection from '../components/TestimonialsSection';
import AuthModal from '../components/AuthModal';
import { motion } from 'motion/react';
import { Sparkles, ArrowRight, Shield, Zap, Target } from 'lucide-react';
import { translations } from '../locales';

export default function LandingPage() {
  const navigate = useNavigate();
  const { setQuery, performSearch, isLoading } = useSearch();
  const { user, language } = useAuth();
  const [showAuth, setShowAuth] = useState(false);
  const t = translations[language];

  const handleAction = (callback: () => void) => {
    if (!user) {
      setShowAuth(true);
    } else {
      callback();
    }
  };

  const handleSearch = (q: string) => {
    handleAction(() => {
      setQuery(q);
      performSearch(q);
      navigate('/dashboard');
    });
  };

  return (
    <div className="relative">
      {/* Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[600px] bg-gradient-to-b from-electric-blue/10 to-transparent blur-[120px] -z-10" />

      {/* Hero Section */}
      <section className="pt-24 pb-32 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-semibold text-electric-blue uppercase tracking-widest mb-8">
              <Sparkles className="w-3 h-3" />
              {t.hero.tag}
            </div>
            
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tight mb-8 leading-[1.1]">
              {language === 'pt' ? (
                <>Encontre seu próximo <span className="gradient-text italic">big ticket</span> lead em segundos.</>
              ) : (
                <>Find your next <span className="gradient-text italic">big ticket</span> lead in seconds.</>
              )}
            </h1>
            
            <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-12">
              {t.hero.subtitle}
            </p>

            <SearchBar onSearch={handleSearch} isLoading={isLoading} focused />
          </motion.div>
        </div>
      </section>

      <LogosStrip />

      {/* Features Grid */}
      <section className="py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Target className="w-8 h-8 text-electric-blue" />}
              title={language === 'pt' ? "Hiper-Segmentado" : "Hyper-Targeted"}
              description={language === 'pt' 
                ? "Filtre por stack tecnológica, rodadas de investimento e níveis precisos de senioridade." 
                : "Filter by tech stack, funding rounds, and precise seniority levels."}
            />
            <FeatureCard 
              icon={<Zap className="w-8 h-8 text-purple-accent" />}
              title={language === 'pt' ? "Dados Verificados" : "Verified Data"}
              description={language === 'pt'
                ? "Nossa IA re-verifica continuamente e-mails e telefones para garantir 98% de precisão."
                : "Our AI continuously re-verifies emails and phone numbers to ensure 98% accuracy."}
            />
            <FeatureCard 
              icon={<Shield className="w-8 h-8 text-slate-300" />}
              title={language === 'pt' ? "Conformidade LGPD/GDPR" : "GDPR Compliant"}
              description={language === 'pt'
                ? "Controles de privacidade de nível empresarial e fontes de dados éticas por padrão."
                : "Enterprise-grade privacy controls and ethical data sourcing by default."}
            />
          </div>
        </div>
      </section>

      <TestimonialsSection />

      {/* Final CTA */}
      <section className="py-32 px-6" id="pricing">
        <div className="max-w-7xl mx-auto">
          <div className="glass-card p-12 md:p-20 text-center relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-electric-blue/20 to-purple-accent/20 opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
            
            <div className="relative z-10">
              <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
                {language === 'pt' ? "Pronto para escalar seu outreach?" : "Ready to scale your outreach?"}
              </h2>
              <p className="text-slate-400 text-lg mb-10 max-w-xl mx-auto">
                {language === 'pt'
                  ? "Comece seu trial de 14 dias sem risco hoje. Cartão de crédito não é necessário para explorar."
                  : "Start your 14-day zero-risk trial today. No credit card required to explore our database."}
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button 
                  onClick={() => handleAction(() => navigate('/dashboard'))}
                  className="btn-primary py-4 px-8 text-lg w-full sm:w-auto"
                >
                  {t.hero.cta}
                  <ArrowRight className="w-5 h-5" />
                </button>
                <button className="btn-outline py-4 px-8 text-lg w-full sm:w-auto" onClick={() => handleAction(() => navigate('/dashboard'))}>
                  {language === 'pt' ? "Ver Planos Enterprise" : "View Enterprise Plans"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} />

      <footer className="py-12 border-t border-glass-border px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-2 text-xl font-bold">
            <Zap className="w-6 h-6 text-electric-blue fill-electric-blue" />
            <span>Nexus</span>
          </div>
          <p className="text-slate-500 text-sm">© 2026 Nexus Leads Inc. {language === 'pt' ? 'Todos os direitos reservados.' : 'All rights reserved.'}</p>
          <div className="flex gap-8 text-sm font-medium text-slate-400">
            <a href="#" className="hover:text-white">{language === 'pt' ? 'Privacidade' : 'Privacy'}</a>
            <a href="#" className="hover:text-white">{language === 'pt' ? 'Termos' : 'Terms'}</a>
            <a href="#" className="hover:text-white">API Docs</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="glass-card p-8 hover:bg-white/5 transition-all group">
      <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="text-xl font-bold text-white mb-3">{title}</h3>
      <p className="text-slate-400 leading-relaxed">{description}</p>
    </div>
  );
}
