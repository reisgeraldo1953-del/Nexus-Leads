/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useSearch } from '../context/SearchContext';
import { useAuth } from '../context/AuthContext';
import { useTrial } from '../hooks/useTrial';
import FilterPanel from '../components/FilterPanel';
import ResultsTable from '../components/ResultsTable';
import SearchBar from '../components/SearchBar';
import PricingModal from '../components/PricingModal';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, Lock, Filter, SlidersHorizontal, Zap, Database } from 'lucide-react';
import { translations } from '../locales';
import { cn } from '../lib/utils';
import { exportLeadsToCSV } from '../lib/exportUtils';

export default function Dashboard() {
  const { results, isLoading, query, setQuery, filters, setFilters, performSearch, isOutOfCredits } = useSearch();
  const { user, language } = useAuth();
  const { isExpired, isProUser } = useTrial(user);
  const [showPricing, setShowPricing] = useState(false);
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const t = translations[language];

  useEffect(() => {
    if (results.length === 0 && !isLoading && !isExpired) {
      performSearch();
    }
  }, []);

  const handleExport = () => {
    if (!isProUser) {
      setShowPricing(true);
    } else {
      exportLeadsToCSV(results, `nexus_leads_${new Date().toISOString().split('T')[0]}.csv`);
    }
  };

  const isAccessBlocked = isExpired || isOutOfCredits;

  return (
    <div className="flex h-[calc(100vh-70px)] bg-navy overflow-hidden relative">
      <div className={cn(
        "fixed inset-0 z-40 lg:relative lg:inset-auto lg:z-0 lg:block transition-transform duration-300",
        showMobileFilters ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        <div className="h-full flex flex-col">
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            <FilterPanel 
              filters={filters} 
              onClose={() => setShowMobileFilters(false)}
              onUpgradeRequest={() => setShowPricing(true)}
              onChange={(f) => {
                setFilters(f);
                performSearch(query, f);
                if (window.innerWidth < 1024) setShowMobileFilters(false);
              }} 
            />
          </div>
          
          {/* Credit Display Widget */}
          <div className="p-6 border-t border-glass-border bg-[#0d121f]">
            <div className="flex items-center justify-between mb-4">
              <span className="text-[10px] font-black uppercase tracking-widest text-text-muted">Usage Stats</span>
              <div className={cn(
                "w-2 h-2 rounded-full",
                isOutOfCredits ? "bg-red-500 animate-pulse" : "bg-emerald-500"
              )} />
            </div>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs mb-2">
                  <span className="text-white font-medium flex items-center gap-1.5">
                    <Database className="w-3 h-3 text-electric-blue" />
                    {language === 'pt' ? 'Buscas' : 'Searches'}
                  </span>
                  <span className="text-text-muted">{user?.credits}/{user?.plan === 'starter' ? '100' : '∞'}</span>
                </div>
                <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: user?.plan === 'starter' ? `${user?.credits}%` : '100%' }}
                    className="h-full bg-electric-blue"
                  />
                </div>
              </div>
              
              {!isProUser && (
                <button 
                  onClick={() => setShowPricing(true)}
                  className="w-full py-2 bg-electric-blue/10 border border-electric-blue/30 text-electric-blue text-[11px] font-bold rounded-lg hover:bg-electric-blue/20 transition-all flex items-center justify-center gap-2"
                >
                  <Zap className="w-3 h-3 fill-electric-blue" />
                  {language === 'pt' ? 'Liberar Ilimitado' : 'Unlock Unlimited'}
                </button>
              )}
            </div>
          </div>
        </div>

        {showMobileFilters && (
          <div 
            onClick={() => setShowMobileFilters(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm lg:hidden -z-10" 
          />
        )}
      </div>

      <div className="flex-1 flex flex-col min-w-0 relative">
        <div className="p-4 md:p-6 border-b border-glass-border flex items-center gap-3">
          <button 
            onClick={() => setShowMobileFilters(true)}
            className="lg:hidden p-3 bg-white/5 border border-glass-border rounded-xl text-slate-400 hover:text-white"
          >
            <SlidersHorizontal className="w-5 h-5" />
          </button>
          <SearchBar onSearch={(q) => {
            setQuery(q);
            performSearch(q, filters);
          }} isLoading={isLoading} />
        </div>

        {isAccessBlocked ? (
          <div className="flex-1 flex items-center justify-center p-8 bg-[#0a0e1a]/50">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card max-w-lg p-12 text-center border-electric-blue/20 shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-electric-blue to-purple-accent" />
              
              <div className="w-20 h-20 rounded-3xl bg-electric-blue/10 flex items-center justify-center mx-auto mb-8 border border-electric-blue/20 rotate-3">
                <Lock className="w-10 h-10 text-electric-blue" />
              </div>
              
              <h2 className="text-3xl font-black text-white mb-4 tracking-tight uppercase">
                {isExpired 
                  ? (language === 'pt' ? 'Trial Expirado' : 'Trial Expired')
                  : (language === 'pt' ? 'Limite Atingido' : 'Limit Reached')
                }
              </h2>
              
              <p className="text-slate-400 mb-10 leading-relaxed">
                {isExpired 
                  ? (language === 'pt' 
                      ? 'Seu período de teste de 14 dias terminou. Faça o upgrade para um plano premium para continuar acessando nosso banco de dados.'
                      : 'Your 14-day trial period has ended. Upgrade to a premium plan to continue accessing our lead database and AI-powered insights.')
                  : (language === 'pt'
                      ? 'Você atingiu o limite de buscas do seu plano. Atualize para o Pro para buscas ilimitadas e exportação de dados.'
                      : 'You have reached your search limit for this month. Upgrade to Pro for unlimited searches and data exports.')
                }
              </p>
              
              <button 
                onClick={() => setShowPricing(true)}
                className="btn-primary w-full py-5 text-lg font-black tracking-wide"
              >
                {language === 'pt' ? 'Fazer Upgrade Agora' : 'Upgrade Now'}
              </button>
            </motion.div>
          </div>
        ) : (
          <ResultsTable 
            leads={results} 
            isLoading={isLoading} 
            onExport={handleExport}
          />
        )}

        {/* Global Loading Overlay */}
        <AnimatePresence>
          {isLoading && results.length > 0 && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-navy/60 backdrop-blur-[4px] z-20 flex items-center justify-center"
            >
              <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 border-4 border-electric-blue/20 border-t-electric-blue rounded-full animate-spin" />
                <span className="text-xs font-bold text-electric-blue uppercase tracking-widest animate-pulse">
                  {language === 'pt' ? 'Calibrando Resultados...' : 'Calibrating Results...'}
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <PricingModal isOpen={showPricing} onClose={() => setShowPricing(false)} />
    </div>
  );
}
