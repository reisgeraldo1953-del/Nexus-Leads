/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string; // ISO string
  plan: 'starter' | 'pro' | 'elite';
  credits: number;
}

export interface Lead {
  id: string;
  name: string;
  avatar: string;
  matchScore: number;
  linkedin: string;
  instagram?: string;
  facebook?: string;
  similarweb?: string;
  google?: string;
  youtube?: string;
  tiktok?: string;
  x?: string;
  company: string;
  role: string;
  location: string;
  sector: string;
  seniority: 'Junior' | 'Mid' | 'Senior' | 'Lead' | 'Executive';
}

export interface SearchFilters {
  location: string;
  sector: string;
  seniority: string;
}
