import { Lead } from '../types';

/**
 * Generates and downloads a CSV file from a list of Leads.
 */
export function exportLeadsToCSV(leads: Lead[], filename: string = 'nexus_leads_export.csv'): void {
  if (leads.length === 0) return;

  const headers = [
    'Name',
    'Role',
    'Company',
    'Location',
    'Match Score',
    'LinkedIn',
    'Website/SimilarWeb',
    'Instagram',
    'Facebook'
  ];

  const rows = leads.map(lead => [
    `"${lead.name.replace(/"/g, '""')}"`,
    `"${lead.role.replace(/"/g, '""')}"`,
    `"${lead.company.replace(/"/g, '""')}"`,
    `"${lead.location.replace(/"/g, '""')}"`,
    lead.matchScore,
    lead.linkedin,
    lead.similarweb || '',
    lead.instagram || '',
    lead.facebook || ''
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map(r => r.join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
