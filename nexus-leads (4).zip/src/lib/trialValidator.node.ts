/**
 * Validates if the user's trial has expired (14 days limit).
 * Assumes 'createdAt' is a JavaScript Date object, an ISO string, or a Firestore Timestamp.
 * 
 * @param {Date | string | any} createdAt - The date the user was created.
 * @returns {boolean} - Returns true if the trial has expired.
 */
export function isTrialExpired(createdAt: Date | string | number): boolean {
  if (!createdAt) return true;

  const createdAtDate = new Date(createdAt);
  const now = new Date();
  
  // Calculate difference in milliseconds
  const diffInMs = now.getTime() - createdAtDate.getTime();
  
  // Convert milliseconds to days
  const diffInDays = diffInMs / (1000 * 60 * 60 * 24);
  
  const TRIAL_PERIOD_DAYS = 14;
  
  return diffInDays >= TRIAL_PERIOD_DAYS;
}

/**
 * Example of how to use this in a Node.js / Express route with a database.
 * This is a conceptual example using a mock database client.
 */
/*
import { isTrialExpired } from './trialValidator';

app.get('/api/leads/search', async (req, res) => {
  const userId = req.user.id;
  const user = await db.users.findUnique({ where: { id: userId } });

  if (isTrialExpired(user.createdAt) && user.plan === 'free') {
    return res.status(403).json({ 
      error: 'Trial expired', 
      message: 'Seu período de teste de 14 dias terminou. Faça o upgrade para continuar.' 
    });
  }

  // Proceed with search logic...
});
*/
