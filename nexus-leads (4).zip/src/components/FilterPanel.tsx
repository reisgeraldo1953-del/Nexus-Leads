/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SearchFilters } from '../types';
import { MapPin, Briefcase, Award, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../locales';

interface FilterPanelProps {
  filters: SearchFilters;
  onChange: (filters: SearchFilters) => void;
  onUpgradeRequest?: () => void;
}

const SECTORS = ['Technology', 'Finance', 'Healthcare', 'Education', 'Marketing', 'Real Estate'];
const LOCATIONS = ['San Francisco, CA', 'New York, NY', 'London, UK', 'Berlin, Germany', 'Sydney, Australia', 'Remote'];
const SENIORITIES = ['Junior', 'Mid', 'Senior', 'Lead', 'Executive'];

export default function FilterPanel({ filters, onChange, onClose, onUpgradeRequest }: FilterPanelProps & { onClose?: () => void }) {
  const { language } = useAuth();
  const t = translations[language];

  const updateFilter = (key: keyof SearchFilters, value: string) => {
    onChange({ ...filters, [key]: value });
  };

  const clearFilters = () => {
    onChange({ location: '', sector: '', seniority: '' });
  };

  const hasFilters = Object.values(filters).some(v => v !== '');

  return (
    <div className="w-full lg:w-[240px] flex flex-col gap-6 md:gap-8 py-6 h-full bg-navy border-r border-glass-border overflow-y-auto px-1">
      <div className="flex items-center justify-between px-4">
        <h3 className="text-[11px] font-bold text-text-muted uppercase tracking-[1px]">{t.search_filters}</h3>
        <div className="flex items-center gap-4">
          {hasFilters && (
            <button 
              onClick={clearFilters}
              className="text-[10px] font-bold text-electric-blue hover:underline"
            >
              {t.clear}
            </button>
          )}
          {onClose && (
            <button onClick={onClose} className="lg:hidden text-slate-400 p-1">
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-col gap-8 px-4">
        <FilterGroup label={t.industry_sector}>
          <div className="flex flex-wrap gap-2">
            {SECTORS.map(sector => (
              <button
                key={sector}
                onClick={() => updateFilter('sector', filters.sector === sector ? '' : sector)}
                className={`chip ${filters.sector === sector ? 'chip-active' : ''}`}
              >
                {sector}
              </button>
            ))}
          </div>
        </FilterGroup>

        <FilterGroup label={t.seniority}>
          <div className="flex flex-wrap gap-2">
            {SENIORITIES.map(level => (
              <button
                key={level}
                onClick={() => updateFilter('seniority', filters.seniority === level ? '' : level)}
                className={`chip ${filters.seniority === level ? 'chip-active' : ''}`}
              >
                {level}
              </button>
            ))}
          </div>
        </FilterGroup>

        <FilterGroup label={t.location}>
           <button
             onClick={() => updateFilter('location', filters.location ? '' : LOCATIONS[0])}
             className={`chip w-full justify-center py-2 ${filters.location ? 'chip-active' : ''}`}
           >
             {filters.location || (language === 'pt' ? 'São Paulo, BR (15km)' : 'San Francisco, CA (15mi)')}
           </button>
        </FilterGroup>
      </div>

      <div className="mt-auto px-4 pb-4">
        <div className="bg-gradient-to-br from-electric-blue to-purple-accent p-5 rounded-2xl flex flex-col gap-2">
          <h4 className="text-sm font-bold text-white">{language === 'pt' ? 'Vá além do Trial' : 'Go beyond Trial'}</h4>
          <p className="text-[10px] text-white/80 leading-relaxed">
            {language === 'pt' 
              ? 'Desbloqueie exportação CSV e busca ilimitada por apenas R$97/mês.' 
              : 'Unlock CSV export and unlimited search for only $19/mo.'}
          </p>
          <button 
            onClick={onUpgradeRequest}
            className="mt-2 w-full py-2 bg-white text-black font-bold text-xs rounded-lg hover:bg-white/90 transition-colors"
          >
            {language === 'pt' ? 'Upgrade para Pro' : 'Upgrade to Pro'}
          </button>
        </div>
      </div>
    </div>
  );
}

function FilterGroup({ label, children }: { label: string, children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-4">
      <div className="text-[11px] font-bold text-text-muted uppercase tracking-[1px]">
        {label}
      </div>
      {children}
    </div>
  );
}
