/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTrial } from '../hooks/useTrial';
import { motion, AnimatePresence } from 'motion/react';
import { Zap, LogOut, User as UserIcon, Globe, Menu, X as CloseIcon } from 'lucide-react';
import AuthModal from './AuthModal';
import { cn } from '../lib/utils';
import { translations } from '../locales';

export default function Navbar() {
  const { user, logout, language, setLanguage } = useAuth();
  const { daysLeft, isProUser } = useTrial(user);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = translations[language];
  const navigate = useNavigate();

  return (
    <nav className="h-[70px] px-4 md:px-10 bg-navy border-b border-glass-border flex items-center justify-between sticky top-0 z-50">
      <Link to="/" className="text-xl md:text-2xl font-extrabold tracking-tighter flex items-center gap-2">
        <span className="text-electric-blue text-lg md:text-2xl">⚡</span>
        <span className="gradient-text">Nexus</span> <span className="hidden sm:inline">Leads</span>
      </Link>

      <div className="hidden lg:flex items-center gap-8">
        <Link to="/dashboard" className="text-sm font-medium text-white">{t.dashboard}</Link>
        <Link to="/" className="text-sm font-medium text-text-muted hover:text-white transition-colors">{t.prospects}</Link>
        <a href="#" className="text-sm font-medium text-text-muted hover:text-white transition-colors">{t.sequences}</a>
        <a href="#" className="text-sm font-medium text-text-muted hover:text-white transition-colors">{t.settings}</a>
      </div>

      <div className="flex items-center gap-3 md:gap-4">
        {/* Language Switcher */}
        <div className="flex bg-white/5 p-1 rounded-lg border border-glass-border shrink-0">
          <button 
            onClick={() => setLanguage('en')}
            className={cn(
              "px-1.5 md:px-2 py-1 text-[9px] md:text-[10px] font-bold rounded transition-all",
              language === 'en' ? "bg-electric-blue text-white" : "text-text-muted hover:text-white"
            )}
          >
            EN
          </button>
          <button 
            onClick={() => setLanguage('pt')}
            className={cn(
              "px-1.5 md:px-2 py-1 text-[9px] md:text-[10px] font-bold rounded transition-all",
              language === 'pt' ? "bg-electric-blue text-white" : "text-text-muted hover:text-white"
            )}
          >
            PT
          </button>
        </div>

        {user ? (
          <div className="flex items-center gap-4">
            {!isProUser && (
              <div className="hidden sm:flex flex-col items-end gap-0.5">
                <div className="bg-electric-blue/10 border border-electric-blue text-electric-blue px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider">
                  {daysLeft} {t.trial_days_remaining}
                </div>
                <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-1">
                  {user.credits} / 100 {language === 'pt' ? 'BUSCAS' : 'SEARCHES'}
                </div>
              </div>
            )}
            <div className="flex items-center gap-2 group cursor-pointer relative">
              <div className="w-8 h-8 rounded-full bg-[#2a2d3e] flex items-center justify-center text-xs font-bold text-text-muted border border-glass-border">
                {user.email.slice(0, 2).toUpperCase()}
              </div>
              <div className="absolute top-10 right-0 w-48 py-2 bg-navy border border-glass-border rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                <div className="px-4 py-2 border-b border-glass-border">
                  <p className="text-sm font-medium text-white truncate">{user.email}</p>
                </div>
                <button 
                  onClick={logout}
                  className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-400 hover:bg-white/5 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  {t.logout}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <button 
            onClick={() => setShowAuthModal(true)}
            className="btn-primary py-2 px-3 md:px-5 text-xs md:text-sm"
          >
            {t.get_started}
          </button>
        )}

        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-2 text-slate-400 hover:text-white transition-colors"
        >
          {mobileMenuOpen ? <CloseIcon className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-[71px] left-0 right-0 bg-navy border-b border-glass-border lg:hidden z-40 p-6 flex flex-col gap-4"
          >
            <Link to="/dashboard" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium text-white py-2 border-b border-white/5">{t.dashboard}</Link>
            <Link to="/" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium text-text-muted py-2 border-b border-white/5">{t.prospects}</Link>
            <a href="#" className="text-lg font-medium text-text-muted py-2 border-b border-white/5">{t.sequences}</a>
            <a href="#" className="text-lg font-medium text-text-muted py-2">{t.settings}</a>
          </motion.div>
        )}
      </AnimatePresence>

      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </nav>
  );
}
