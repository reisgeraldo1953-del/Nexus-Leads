/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useAuth } from '../context/AuthContext';

const LOGOS = ['TECHVINE', 'GLOBO', 'ZYX_ELITE', 'NORDIC_UI', 'SPECTER'];

export default function LogosStrip() {
  const { language } = useAuth();
  
  return (
    <div className="py-12 border-y border-glass-border bg-white/2 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-electric-blue/5 via-transparent to-purple-accent/5" />
      <div className="max-w-7xl mx-auto px-6 overflow-hidden relative z-10">
        <div className="text-center mb-6">
          <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-slate-500">
            {language === 'pt' ? 'Confiado por líderes globais' : 'Trusted by global industry leaders'}
          </p>
        </div>
        <div className="flex flex-wrap justify-center md:justify-between items-center gap-12 grayscale opacity-40 hover:grayscale-0 hover:opacity-100 transition-all">
          {LOGOS.map((logo) => (
            <span 
              key={logo} 
              className="text-xl font-black italic tracking-tighter text-slate-300"
            >
              {logo}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
