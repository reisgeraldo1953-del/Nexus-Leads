/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Search, Loader2, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../locales';

interface SearchBarProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
  focused?: boolean;
}

export default function SearchBar({ onSearch, isLoading, focused = false }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const { language } = useAuth();
  const t = translations[language];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-3xl mx-auto">
      <div className="flex gap-3">
        <div className="flex-1 flex items-center gap-3 bg-glass border border-glass-border rounded-xl px-5 py-2">
          <Search className="w-5 h-5 text-text-muted" />
          <input 
            type="text"
            autoFocus={focused}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t.search_placeholder}
            className="flex-1 bg-transparent py-3 text-base text-white placeholder-text-muted focus:outline-none"
          />
        </div>
        <button 
          type="submit" 
          disabled={isLoading}
          className="btn-primary min-w-[50px] md:min-w-[140px]"
        >
          {isLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <>
              <span className="hidden md:inline">{t.search_button}</span>
              <Search className="w-5 h-5 md:hidden" />
            </>
          )}
        </button>
      </div>
    </form>
  );
}
