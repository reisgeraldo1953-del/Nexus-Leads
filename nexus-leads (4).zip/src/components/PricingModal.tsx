/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check, Zap, ShieldCheck, Crown } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../locales';

interface PricingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function PricingModal({ isOpen, onClose }: PricingModalProps) {
  const { language, updatePlan } = useAuth();
  const pricingT = translations[language].pricing;

  const handleUpgrade = (planType: 'starter' | 'pro' | 'elite') => {
    updatePlan(planType);
    onClose();
  };

  const plans = [
    {
      type: 'starter' as const,
      name: pricingT.starter,
      price: language === 'pt' ? 'R$ 249' : '$49',
      period: pricingT.monthly,
      icon: <Zap className="w-6 h-6 text-slate-400" />,
      features: language === 'pt' 
        ? ['100 buscas / mês', 'Filtros básicos', 'Integração LinkedIn', 'Suporte padrão']
        : ['100 searches / month', 'Basic filters', 'LinkedIn integration', 'Standard support'],
      cta: pricingT.cta_starter,
      popular: false,
      color: 'border-white/10'
    },
    {
      type: 'pro' as const,
      name: pricingT.pro,
      price: language === 'pt' ? 'R$ 499' : '$99',
      period: pricingT.monthly,
      icon: <ShieldCheck className="w-6 h-6 text-electric-blue" />,
      features: language === 'pt'
        ? ['Buscas ilimitadas', 'Filtros avançados', 'Exportação CSV', 'Suporte prioritário', 'Dados de stack tecnológica']
        : ['Unlimited searches', 'Granular filters', 'CSV Exports', 'Priority support', 'Tech stack info'],
      cta: pricingT.cta_pro,
      popular: true,
      color: 'border-electric-blue/50 ring-2 ring-electric-blue/20'
    },
    {
      type: 'elite' as const,
      name: pricingT.elite,
      price: language === 'pt' ? 'R$ 4.490' : '$890',
      period: pricingT.yearly,
      icon: <Crown className="w-6 h-6 text-purple-accent" />,
      features: language === 'pt'
        ? ['Tudo do Pro', 'IA personalizada', 'Acesso direto via API', 'Gerente de conta dedicado', 'Workspaces colaborativos']
        : ['Everything in Pro', 'Custom AI fine-tuning', 'Direct API access', 'Dedicated manager', 'Team collaborative workspaces'],
      cta: pricingT.cta_elite,
      popular: false,
      color: 'border-purple-accent/50'
    }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-navy/90 backdrop-blur-md"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-5xl z-10 max-h-[90vh] overflow-y-auto custom-scrollbar"
          >
            <button 
              onClick={onClose}
              className="absolute -top-12 right-0 p-2 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="text-center mb-10 px-4">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 tracking-tight">{pricingT.title}</h2>
              <p className="text-slate-400 max-w-2xl mx-auto text-sm md:text-base"> Choose the plan that fits your growth ambitions. All plans include 256-bit encryption and real-time data sync.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 px-4 pb-8">
              {plans.map((plan) => (
                <div 
                  key={plan.name}
                  className={`relative glass-card p-8 flex flex-col bg-navy/50 hover:bg-navy/60 transition-all duration-300 ${plan.color} group`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-electric-blue rounded-full text-[10px] font-black uppercase tracking-widest text-white shadow-lg shadow-electric-blue/40 z-20">
                      {language === 'pt' ? 'Mais Popular' : 'Most Popular'}
                    </div>
                  )}

                  <div className="mb-8">
                    <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6 ring-1 ring-white/10 group-hover:ring-electric-blue/30 transition-all">
                      {plan.icon}
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl font-black text-white">{plan.price}</span>
                      <span className="text-slate-500 font-medium text-sm">{plan.period}</span>
                    </div>
                  </div>

                  <ul className="space-y-4 mb-8 flex-1">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-3 text-sm text-slate-400 leading-relaxed">
                        <Check className="w-4 h-4 text-electric-blue shrink-0 mt-0.5" />
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <button 
                    onClick={() => handleUpgrade(plan.type)}
                    className={`w-full py-4 px-6 rounded-xl font-bold text-center transition-all active:scale-[0.98] ${
                      plan.popular 
                        ? 'bg-gradient-to-r from-electric-blue to-purple-accent text-white hover:shadow-xl hover:shadow-electric-blue/20' 
                        : 'bg-white/5 text-white border border-white/10 hover:bg-white/10'
                    }`}
                  >
                    {plan.cta}
                  </button>
                </div>
              ))}
            </div>
            
            <div className="text-center mt-4 mb-10 text-[10px] md:text-xs text-slate-500 max-w-xs mx-auto">
              Need a custom plan for your organization? <button className="text-electric-blue font-bold hover:underline">Contact our Sales team</button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
