/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Lead } from '../types';
import { Linkedin, MoreHorizontal, Download, ArrowRight, Instagram, Facebook, Globe, Search, Youtube, Music2, Twitter } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../locales';
import { cn } from '../lib/utils';

interface ResultsTableProps {
  leads: Lead[];
  isLoading: boolean;
  onExport: () => void;
}

export default function ResultsTable({ leads, isLoading, onExport }: ResultsTableProps) {
  const { language } = useAuth();
  const t = translations[language];

  if (isLoading) {
    return (
      <div className="flex-1 p-8 space-y-4">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="h-16 glass-card animate-shimmer opacity-50 overflow-hidden" />
        ))}
      </div>
    );
  }

  if (leads.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-20 text-center">
        <div className="w-16 h-16 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center mb-6">
          <MoreHorizontal className="w-8 h-8 text-slate-500" />
        </div>
        <h3 className="text-xl font-bold text-white mb-2">{language === 'pt' ? 'Nenhum lead encontrado' : 'No leads found'}</h3>
        <p className="text-slate-400 max-w-sm">{language === 'pt' ? 'Tente ajustar sua busca ou filtros para ver mais resultados.' : 'Try adjusting your search query or filters to find more relevant leads.'}</p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-x-hidden overflow-y-auto">
      <div className="px-4 md:px-10 py-4 md:py-6 border-b border-glass-border flex flex-col sm:flex-row items-start sm:items-center justify-between sticky top-0 bg-navy z-10 gap-4">
        <div>
          <h2 className="text-lg md:text-xl font-bold text-white">{t.search_results}</h2>
          <p className="text-[10px] md:text-[11px] text-text-muted mt-0.5">
            {t.showing_potential_leads.replace('{count}', leads.length.toString())}
          </p>
        </div>
        <button 
          onClick={onExport}
          className="btn-outline w-full sm:w-auto text-xs py-2.5"
        >
          <Download className="w-3.5 h-3.5" />
          {t.export_csv}
        </button>
      </div>

      <div className="w-full overflow-x-auto custom-scrollbar">
        <table className="w-full border-collapse min-w-[800px]">
          <thead>
            <tr className="border-b border-glass-border">
              <th className="px-4 md:px-10 py-4 text-left text-[11px] font-bold text-text-muted uppercase tracking-[0.5px]">{t.lead}</th>
              <th className="px-4 md:px-6 py-4 text-left text-[11px] font-bold text-text-muted uppercase tracking-[0.5px]">{t.match} %</th>
              <th className="px-4 md:px-6 py-4 text-left text-[11px] font-bold text-text-muted uppercase tracking-[0.5px]">{t.company}</th>
              <th className="px-4 md:px-6 py-4 text-left text-[11px] font-bold text-text-muted uppercase tracking-[0.5px]">{t.location}</th>
              <th className="px-4 md:px-10 py-4 text-right text-[11px] font-bold text-text-muted uppercase tracking-[0.5px]">{t.actions}</th>
            </tr>
          </thead>
          <tbody>
            {leads.map((lead, idx) => (
              <motion.tr
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                key={lead.id}
                className="border-b border-glass-border hover:bg-white/[0.02] transition-colors group cursor-pointer"
              >
                <td className="px-4 md:px-10 py-4 text-nowrap">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-electric-blue/20 border border-electric-blue/30 flex items-center justify-center overflow-hidden shrink-0">
                      <img src={lead.avatar} alt={lead.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-white group-hover:text-electric-blue transition-colors">
                        {lead.name}
                      </div>
                      <div className="text-[11px] text-text-muted">{lead.role}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 md:px-6 py-4">
                  <span className="bg-[#00FF80]/10 text-[#00FF80] text-[12px] font-bold px-2 py-1 rounded">
                    {lead.matchScore}%
                  </span>
                </td>
                <td className="px-4 md:px-6 py-4">
                  <div className="flex items-center gap-2">
                    <span className="text-[13px] text-text-muted truncate max-w-[120px]">{lead.company}</span>
                    {lead.matchScore > 90 && (
                      <span className="bg-yellow-400 text-black text-[8px] font-black px-1.5 py-0.5 rounded uppercase shrink-0">Elite</span>
                    )}
                  </div>
                </td>
                <td className="px-4 md:px-6 py-4">
                  <span className="text-[13px] text-text-muted truncate max-w-[120px]">{lead.location}</span>
                </td>
                <td className="px-4 md:px-10 py-4">
                  <div className="flex items-center justify-end gap-1.5 flex-wrap max-w-[200px]">
                    <SocialIcon href={lead.linkedin} icon={<Linkedin className="w-3.5 h-3.5" />} color="bg-[#0077b5]/10 text-[#0077b5]" />
                    <SocialIcon href={lead.instagram} icon={<Instagram className="w-3.5 h-3.5" />} color="bg-[#e4405f]/10 text-[#e4405f]" />
                    <SocialIcon href={lead.x} icon={<Twitter className="w-3.5 h-3.5" />} color="bg-white/10 text-white" />
                    <SocialIcon href={lead.facebook} icon={<Facebook className="w-3.5 h-3.5" />} color="bg-[#1877f2]/10 text-[#1877f2]" />
                    <SocialIcon href={lead.similarweb} icon={<Globe className="w-3.5 h-3.5" />} color="bg-[#ff8f00]/10 text-[#ff8f00]" />
                    <SocialIcon href={lead.youtube} icon={<Youtube className="w-3.5 h-3.5" />} color="bg-[#ff0000]/10 text-[#ff0000]" />
                    <SocialIcon href={lead.tiktok} icon={<Music2 className="w-3.5 h-3.5" />} color="bg-[#ee1d52]/10 text-[#ee1d52]" />
                  </div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
        
        {leads.length > 0 && (
          <div className="p-8 text-center text-xs text-text-muted">
             {language === 'pt' 
               ? `Exibindo ${leads.length} de ${leads.length * 5} resultados para sua busca`
               : `Showing ${leads.length} of ${leads.length * 5} results for your search`}
          </div>
        )}
      </div>
    </div>
  );
}

function SocialIcon({ href, icon, color = "bg-transparent border border-glass-border text-text-muted hover:text-white hover:bg-white/5" }: { href?: string, icon: React.ReactNode, color?: string }) {
  if (!href) return null;
  return (
    <a 
      href={href} 
      target="_blank" 
      rel="noopener noreferrer"
      className={cn(
        "p-1.5 rounded transition-all shrink-0 hover:scale-110 active:scale-95",
        color
      )}
    >
      {icon}
    </a>
  );
}
