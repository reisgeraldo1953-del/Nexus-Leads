/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Quote } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../locales';

const TESTIMONIALS = [
  {
    name: 'Sarah Chen',
    role: 'Head of Sales',
    company: 'VeloCloud',
    en: 'Nexus identified exactly the type of executives we were looking for in minutes. The match score is eerily accurate.',
    pt: 'A Nexus identificou exatamente o tipo de executivos que estávamos procurando em minutos. A pontuação de match é assustadoramente precisa.',
    avatar: 'https://picsum.photos/seed/sarah/100/100'
  },
  {
    name: 'Marcus Thorne',
    role: 'Founder',
    company: 'Astra Labs',
    en: 'We switched from Apollo and haven’t looked back. The interface is cleaner and the lead quality is significantly higher.',
    pt: 'Mudamos da Apollo e não nos arrependemos. A interface é mais limpa e a qualidade dos leads é significativamente maior.',
    avatar: 'https://picsum.photos/seed/marcus/100/100'
  },
  {
    name: 'Elena Rodriguez',
    role: 'VP Marketing',
    company: 'Quantize',
    en: 'The trial convinced our entire team. Within the first 14 days, we closed two high-ticket enterprise contracts.',
    pt: 'O trial convenceu toda a nossa equipe. Nos primeiros 14 dias, fechamos dois contratos corporativos de alto valor.',
    avatar: 'https://picsum.photos/seed/elena/100/100'
  }
];

export default function TestimonialsSection() {
  const { language } = useAuth();
  const t = translations[language].testimonials;

  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">{t.title}</h2>
          <p className="text-slate-400">{t.subtitle}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((testimonial, idx) => (
            <div 
              key={idx}
              className="glass-card p-8 relative hover:border-electric-blue/30 transition-all group"
            >
              <Quote className="absolute top-6 right-6 w-8 h-8 text-white/5 transition-colors group-hover:text-electric-blue/10" />
              <p className="text-slate-300 mb-8 leading-relaxed italic">"{testimonial[language]}"</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full overflow-hidden border border-white/10">
                  <img src={testimonial.avatar} alt={testimonial.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">{testimonial.name}</h4>
                  <p className="text-xs text-slate-500">{testimonial.role} @ {testimonial.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
