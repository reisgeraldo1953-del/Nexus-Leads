import { useState, useEffect } from 'react';
import { User } from '../types';

export function useTrial(user: User | null) {
  const [trialInfo, setTrialInfo] = useState({
    daysLeft: 14,
    isExpired: false,
    isProUser: false,
  });

  useEffect(() => {
    if (!user) return;

    const createdAt = new Date(user.createdAt).getTime();
    const now = Date.now();
    const diffInMs = now - createdAt;
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
    
    const daysRemaining = Math.max(0, 14 - diffInDays);
    const isPro = user.plan === 'pro' || user.plan === 'elite';

    setTrialInfo({
      daysLeft: daysRemaining,
      isExpired: !isPro && daysRemaining <= 0,
      isProUser: isPro,
    });
  }, [user]);

  return trialInfo;
}
