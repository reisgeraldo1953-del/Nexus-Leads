/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Lead, SearchFilters } from '../types';
import { searchLeads } from '../services/leadsApi';
import { useAuth } from './AuthContext';

interface SearchContextType {
  query: string;
  setQuery: (q: string) => void;
  filters: SearchFilters;
  setFilters: (f: SearchFilters) => void;
  results: Lead[];
  isLoading: boolean;
  isOutOfCredits: boolean;
  performSearch: (q?: string, f?: SearchFilters) => Promise<void>;
}

const SearchContext = createContext<SearchContextType | undefined>(undefined);

export function SearchProvider({ children }: { children: ReactNode }) {
  const { consumeCredit } = useAuth();
  const [query, setQuery] = useState('');
  const [filters, setFilters] = useState<SearchFilters>({
    location: '',
    sector: '',
    seniority: '',
  });
  const [results, setResults] = useState<Lead[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isOutOfCredits, setIsOutOfCredits] = useState(false);

  const performSearch = async (q = query, f = filters) => {
    setIsLoading(true);
    setIsOutOfCredits(false);
    
    try {
      const hasCredits = consumeCredit();
      if (!hasCredits) {
        setIsOutOfCredits(true);
        setIsLoading(false);
        return;
      }

      const leads = await searchLeads(q, f);
      setResults(leads);
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SearchContext.Provider
      value={{
        query,
        setQuery,
        filters,
        setFilters,
        results,
        isLoading,
        isOutOfCredits,
        performSearch,
      }}
    >
      {children}
    </SearchContext.Provider>
  );
}

export function useSearch() {
  const context = useContext(SearchContext);
  if (context === undefined) {
    throw new Error('useSearch must be used within a SearchProvider');
  }
  return context;
}
