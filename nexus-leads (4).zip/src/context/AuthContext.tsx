/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string) => void;
  logout: () => void;
  updatePlan: (plan: 'starter' | 'pro' | 'elite') => void;
  consumeCredit: () => boolean;
  isLoading: boolean;
  language: 'en' | 'pt';
  setLanguage: (lang: 'en' | 'pt') => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [language, setLanguage] = useState<'en' | 'pt'>('en');

  useEffect(() => {
    const savedUser = localStorage.getItem('nexus_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    const savedLang = localStorage.getItem('nexus_lang') as 'en' | 'pt';
    if (savedLang) {
      setLanguage(savedLang);
    }
    setIsLoading(false);
  }, []);

  const handleSetLanguage = (lang: 'en' | 'pt') => {
    setLanguage(lang);
    localStorage.setItem('nexus_lang', lang);
  };

  const login = (email: string) => {
    const newUser: User = {
      id: Math.random().toString(36).substring(7),
      email,
      name: email.split('@')[0],
      createdAt: new Date().toISOString(),
      plan: 'starter',
      credits: 100,
    };
    localStorage.setItem('nexus_user', JSON.stringify(newUser));
    setUser(newUser);
  };

  const updatePlan = (plan: 'starter' | 'pro' | 'elite') => {
    if (!user) return;
    const updatedUser: User = { ...user, plan, credits: plan === 'starter' ? 100 : 999999 };
    localStorage.setItem('nexus_user', JSON.stringify(updatedUser));
    setUser(updatedUser);
  };

  const consumeCredit = (): boolean => {
    if (!user) return false;
    if (user.plan === 'starter' && user.credits <= 0) return false;
    
    const updatedUser: User = { ...user, credits: Math.max(0, user.credits - 1) };
    localStorage.setItem('nexus_user', JSON.stringify(updatedUser));
    setUser(updatedUser);
    return true;
  };

  const logout = () => {
    localStorage.removeItem('nexus_user');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      login, 
      logout, 
      updatePlan,
      consumeCredit,
      isLoading, 
      language, 
      setLanguage: handleSetLanguage 
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
