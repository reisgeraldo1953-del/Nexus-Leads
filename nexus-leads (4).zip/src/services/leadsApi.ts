import { Lead, SearchFilters } from '../types';

const SECTORS = ['Technology', 'Finance', 'Healthcare', 'Education', 'Marketing', 'Real Estate'];
const LOCATIONS = ['San Francisco, CA', 'New York, NY', 'London, UK', 'Berlin, Germany', 'Sydney, Australia', 'Remote'];
const ROLES = ['Software Engineer', 'Product Manager', 'Sales Director', 'Marketing Lead', 'CEO', 'CTO', 'Operations Manager'];

const NAMES = [
  'Alexandre Silva', 'Beatriz Santos', 'Carlos Oliveira', 'Daniela Costa', 'Eduardo Pereira',
  'Fernanda Lima', 'Gabriel Rodrigues', 'Helena Sousa', 'Igor Martins', 'Juliana Carvalho',
  'Kevin Smith', 'Sarah Johnson', 'Michael Brown', 'Emily Davis', 'David Wilson',
  'James Anderson', 'Maria Garcia', 'Robert Taylor', 'Linda Martinez', 'William Thomas'
];

const COMPANIES = [
  'TechNova Solutions', 'FinEdge Analytics', 'HealthPulse Systems', 'EduStream Learning',
  'MarketMagnet', 'TerraForm Real Estate', 'Nexus Logic', 'Vantage AI', 'Pulse Metrics',
  'Stellar Dynamics', 'CloudScale Inc.', 'DataFlow Corp', 'GreenHorizon', 'Quantum Leap',
  'Solaris Energy', 'BioSynth', 'InfraStructure', 'Visionary Soft', 'Apex Global', 'Zenith Systems'
];

export const mockLeads: Lead[] = Array.from({ length: 100 }, (_, i) => ({
  id: `lead-${i}`,
  name: NAMES[i % NAMES.length] + (i > 20 ? ` ${String.fromCharCode(65 + (i % 26))}.` : ''),
  avatar: `https://picsum.photos/seed/lead-user-${i}/100/100`,
  matchScore: Math.floor(Math.random() * 35) + 65, // 65-100
  linkedin: `https://linkedin.com/in/nexus-lead-${i}`,
  instagram: `https://instagram.com/nexus_lead_${i}`,
  facebook: `https://facebook.com/leads/nexus_${i}`,
  similarweb: `https://similarweb.com/website/${COMPANIES[i % COMPANIES.length].toLowerCase().replace(/\s+/g, '')}.com`,
  google: `https://google.com/search?q=${COMPANIES[i % COMPANIES.length].replace(/\s+/g, '+')}`,
  youtube: `https://youtube.com/@nexus_prospect_${i}`,
  tiktok: `https://tiktok.com/@nexus_pro_${i}`,
  x: `https://x.com/nexus_leads_${i}`,
  company: COMPANIES[i % COMPANIES.length],
  role: ROLES[i % ROLES.length],
  location: i % 10 === 0 ? 'Remote' : LOCATIONS[i % LOCATIONS.length],
  sector: SECTORS[i % SECTORS.length],
  seniority: ['Junior', 'Mid', 'Senior', 'Lead', 'Executive'][i % 5] as Lead['seniority'],
}));

export async function searchLeads(query: string, filters: SearchFilters): Promise<Lead[]> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1200));

  return mockLeads.filter(lead => {
    const matchesQuery = !query || 
      lead.name.toLowerCase().includes(query.toLowerCase()) ||
      lead.company.toLowerCase().includes(query.toLowerCase()) ||
      lead.role.toLowerCase().includes(query.toLowerCase());
    
    const matchesLocation = !filters.location || lead.location === filters.location;
    const matchesSector = !filters.sector || lead.sector === filters.sector;
    const matchesSeniority = !filters.seniority || lead.seniority === filters.seniority;

    return matchesQuery && matchesLocation && matchesSector && matchesSeniority;
  });
}
